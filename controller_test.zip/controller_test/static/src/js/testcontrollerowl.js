import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";



export class TestControllerOWL extends Component{
    static template = "TestControllerOWL.test_controller_owl"
    setup(){

    }
}