from odoo import models,fields,api

class TestController(models.Model):
    _name="test.controller"
    _description = "Test Controller"
    
    image_128 = fields.Binary(string="Image")
    name = fields.Char(string="Name")
    price = fields.Float(string="Price")
    discount = fields.Float(string="Discount")
    total = fields.Float(string="Total",compute="totalprice")
    
    
    @api.depends('price','discount')
    
    def totalprice(self):
        for rec in self:
            
            rec.total = rec.price - (rec.price * rec.discount)/100
    